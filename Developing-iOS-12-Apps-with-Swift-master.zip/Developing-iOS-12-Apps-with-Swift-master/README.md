# Developing iOS 12 Apps with Swift 4.2

It's a repo of the projects and examples described in the `CS193P` course at Stanford University.

## Lecture 1 : Introduction to iOS12 XCode 10 and Swift4.2
In the first part of the course, Michel Deiman iOS general structure and course content are mentioned.
Then he shows the board demo version of the card matching game and says we will do a similar project.
It opens XCode and mentions it. How can we give a name to our project and do what it says on the board in software?
explains step by step. By using 4 buttons and 1 label, we make an entry to our "Card Matching" game.


## Lecture 2: MVC
In the second part of the lecture, Michel Deiman talks about the MVC structure. Introducing the lesson from the pdfs about MVC and doing this
It provides necessary information on the subject. After learning the MVC structure theoretically, we started our project from where we left off.
We continue. We add two .swift files. One uses the Class structure. In the other
Struct structure is used. In our "Card Matching" game, matching operations can be done by going even further.
